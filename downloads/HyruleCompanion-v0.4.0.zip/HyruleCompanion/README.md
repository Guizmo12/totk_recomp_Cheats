# Hyrule Companion 0.4.0

Interface refondue : bleu nuit, cadres or, accents turquoise Sheikah, quatre onglets natifs et animations réduisibles. Voir REFONTE.md pour les contrôles et limites de vérification.

A local Windows trainer for your **TOTK 1.2.1 recomp, release 0.1.1+701bd62**.

Open **HyruleCompanion.exe**, start TOTK and load your save, then click **Connect to game**. Keep the app's `assets` folder beside the executable.

## Item browser

Browse 568 spawn-eligible entries with pictures, category/type filters, name or actor-ID search, favorites and recent selections. Select an item, choose **1–25** copies and **1–10 meters**, then click **Spawn item**. The app normally returns focus to TOTK so the game can finish creating the item. Change this behavior in Settings.

**Ctrl+Alt+S** spawns the selected item while the game is focused. Customize this shortcut in Settings. Real spawning is verified with an apple on this exact executable; other actors remain experimental. The app checks that each requested actor finishes loading before reporting success.

Arrows use collectible pickups. **Arrows ×5** and **Arrows ×10** are separate bundle entries; quantity counts bundles, so quantity 2 of Arrows ×5 creates 10 arrows.

Armor, prepared food and Crystallized Charge are excluded from the spawn browser. Favorite IDs and the complete underlying 1,337-entry catalog remain intact.

Before the first spawn or teleport, the app copies your game saves to **backups/before-first-spawn**. The executable on disk is not changed; its frame callback is restored when the app disconnects or closes.

## Cheats and shortcuts

All cheats start **off**. Use the switches or, while playing:

| Shortcut | Control |
|---|---|
| Ctrl+Alt+1 | Infinite health |
| Ctrl+Alt+2 | Infinite stamina |
| Ctrl+Alt+3 | Infinite battery |
| Ctrl+Alt+4 | Equipped weapon, bow and shield durability refill |
| Ctrl+Alt+5 | 999 arrows |
| Ctrl+Alt+6 | 999,999 rupees |
| Ctrl+Alt+7 | Movement speed |
| Ctrl+Alt+8 | High jump, experimental: hold Space or Xbox Y |
| Ctrl+Alt+F12 | Disable every cheat |
| Ctrl+F | Search items in this app |

Set speed and jump multipliers below the cheat list. Switching speed off restores its original value. Switching refills or currency off stops further changes; items, restored durability and currency already granted remain in the game.

**No fall damage is not implemented for this build.** High jump remains experimental and is limited to Space or an Xbox-compatible controller's Y button.

## Travel

Name and save your current position, select a saved place, and use **Travel to selected place**. **Undo last teleport** returns to the position before that trip. This preview limits travel to 2,000 meters within the current game world.

Favorites, shortcuts, saved places and window preferences are kept locally in `user-settings.json`. The app does not use an account or a network connection.

See **SOURCES.md** and **CATALOG-LICENSE.txt** for credits. The separate source package contains the project and verification checks.


## 0.2.1 — spawn browser corrections
Armor, all prepared Food entries (meals and elixirs), and Crystallized Charge are excluded from the item browser and blocked by the spawn action. The original catalog and saved favorite IDs remain intact. Raw ingredients and arrow bundles remain available. There are 568 browser entries after these exclusions. Pagination was replaced with a continuous, row-virtualized scrolling grid; wheel input over the cards scrolls the results. Verification: 22 logic tests, full-list/end-of-list selection, exclusion checks, favorites, filters, and layout checks on all four tabs. No game-memory writes were required for these checks.


## Interactive Travel 0.3.0
The Travel tab now has an offline three-layer map, 69,299 searchable points, 354 persistent category filters, arbitrary coordinate teleporting, HUD/engine coordinate formats and Undo. See TRAVEL.md for controls, coordinate conventions and verification limits. The old 2,000-meter restriction is removed.


## Expanded map 0.4.0
Travel now contains 69,299 offline points and 354 filters, covering quests, Koroks, chests, caves, wells, shops, bosses, equipment, materials and creatures across all three layers. Combine searchable grouped checkboxes; use Explore, All, None or Travel presets. Dense markers cluster and split as you zoom. Filter preferences save automatically. Read TRAVEL.md for controls, attribution and altitude limitations. Version 0.4.0 passed 30 logic/native-callback checks and the native four-screen visual review. Gameplay write tests from previous releases remain historical.
