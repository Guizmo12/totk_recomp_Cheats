# Hyrule Companion 0.6.3

Interface refondue : bleu nuit, cadres or, accents turquoise Sheikah, quatre onglets natifs et animations réduisibles. Voir REFONTE.md pour les contrôles et limites de vérification.

A local Windows trainer for your **TOTK 1.2.1 recomp, releases 0.1.1+701bd62, 0.3.11+0ae47a5, 0.4.0+7a37fc3c, 0.4.1+6151ac4f, and 0.5.0+afae80c9**.

Open **HyruleCompanion.exe**, start TOTK and load your save, then click **Connect to game**. Keep the app's `assets` folder beside the executable.

## Item browser

Browse 568 spawn-eligible entries with pictures, category/type filters, name or actor-ID search, favorites and recent selections. Select an item, choose **1–25** copies and **1–10 meters**, then click **Spawn item**. The app normally returns focus to TOTK so the game can finish creating the item. Change this behavior in Settings.

**Ctrl+Alt+S** spawns the selected item while the game is focused. Customize this shortcut in Settings. Real spawning is verified with an apple on this exact executable; other actors remain experimental. The app checks that each requested actor finishes loading before reporting success.

Arrows use collectible pickups. **Arrows ×5** and **Arrows ×10** are separate bundle entries; quantity counts bundles, so quantity 2 of Arrows ×5 creates 10 arrows.

Armor, prepared food and Crystallized Charge are excluded from the spawn browser. Favorite IDs and the complete underlying 1,337-entry catalog remain intact.

Before the first spawn or teleport, the app copies your game saves to **backups/before-first-spawn**. The executable on disk is not changed; its frame callback is restored when the app disconnects or closes.

## Cheats and shortcuts

All cheats start **off**. Use the switches or, while playing:

| Shortcut | Control |
|---|---|
| Ctrl+Alt+1 | Infinite health |
| Ctrl+Alt+2 | Infinite stamina |
| Ctrl+Alt+3 | Infinite battery |
| Ctrl+Alt+4 | Equipped weapon, bow and shield durability refill |
| Ctrl+Alt+5 | 999 arrows |
| Ctrl+Alt+6 | 999,999 rupees |
| Ctrl+Alt+7 | Movement speed |
| Ctrl+Alt+8 | High jump, experimental: hold Space or Xbox Y |
| Ctrl+Alt+F12 | Disable every cheat |
| Ctrl+F | Search items in this app |

Set speed and jump multipliers below the cheat list. Switching speed off restores its original value. Switching refills or currency off stops further changes; items, restored durability and currency already granted remain in the game.

**No fall damage is not implemented for this build.** High jump remains experimental and is limited to Space or an Xbox-compatible controller's Y button.

## Travel

Name and save your current position, select a saved place, and use **Travel to selected place**. **Undo last teleport** returns to the position before that trip. This preview limits travel to 2,000 meters within the current game world.

Favorites, shortcuts, saved places and window preferences are kept locally in `user-settings.json`. The app does not use an account or a network connection.

See **SOURCES.md** and **CATALOG-LICENSE.txt** for credits. The separate source package contains the project and verification checks.


## 0.2.1 — spawn browser corrections
Armor, all prepared Food entries (meals and elixirs), and Crystallized Charge are excluded from the item browser and blocked by the spawn action. The original catalog and saved favorite IDs remain intact. Raw ingredients and arrow bundles remain available. There are 568 browser entries after these exclusions. Pagination was replaced with a continuous, row-virtualized scrolling grid; wheel input over the cards scrolls the results. Verification: 22 logic tests, full-list/end-of-list selection, exclusion checks, favorites, filters, and layout checks on all four tabs. No game-memory writes were required for these checks.


## Interactive Travel 0.3.0
The Travel tab now has an offline three-layer map, 49 main category filters, a separate optional compendium, zoom-dependent markers, arbitrary coordinate teleporting, HUD/engine coordinate formats and Undo. See TRAVEL.md for controls, coordinate conventions and verification limits. The old 2,000-meter restriction is removed.


## Map filters 0.4.1
The main filter panel follows Zelda Dungeon’s 49 categories and seven groups: Travel Gates, Quests, Collectibles, Locations, Services, Other and Bosses. Individual resources are in a separate optional Compendium section. All/None and grouped checkboxes control visibility; finer markers appear as you zoom in. Existing custom-coordinate travel, saved places and Undo remain available. Release build, 32 checks and the native four-screen review passed. See TRAVEL.md.


## Recomp 0.3.11 and original-build support — 0.5.0
Automatic compatibility profiles support the original 0.1.1 and installed 0.3.11 Windows builds with TOTK game update 1.2.1. Spawning and travel select the correct native addresses; cheat data checks and preferences are preserved. The connection badge shows the detected recomp version. Release build, 36 checks, a live speed write/restore, one collectible apple and a short teleport/return passed on v0.3.11. See [COMPATIBILITY.md](COMPATIBILITY.md) for exact executable profiles and verification limits.

## Recomp 0.4.0 support — 0.5.1

All 37 automated checks passed. In live gameplay on recomp 0.4.0 with TOTK 1.2.1, the app read all eight supported cheat values. Movement speed changed and restored exactly. A short teleport moved Link and returned him to his starting position. One apple spawned with a Take prompt. The app reconnected after closing, verified all three restored native function signatures, and left every cheat off. The four-tab interface checks passed. The older profiles passed regression checks and their gameplay verification is historical. See [COMPATIBILITY.md](COMPATIBILITY.md) for the exact Windows executable profiles.

## Free Autobuild

On the supported Windows v3 recomp 0.4.1 and 0.5.0 builds with TOTK 1.2.1, open **Cheats → Inventory** and switch on **Free Autobuild**. Restart the game after either change. The switch installs or removes a local mod in the default mods folder. It generates a replacement actor table from your game files and sets only the Autobuild replacement cost to zero. Keep the mod enabled in the recomp mod menu. The companion checks for conflicting actor tables before installing. All 15,369 generated rows were compared with the original. In-game spending still needs a gameplay check.
